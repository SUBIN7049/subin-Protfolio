package com.code.bowwow.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.code.bowwow.entity.order;
import com.code.bowwow.entity.order_detail;
import com.code.bowwow.entity.product;
import com.code.bowwow.entity.review;
import com.code.bowwow.entity.user;
import com.code.bowwow.dao.bowwowDAO;

@Service("bowwowService")
public class bowwowServiceImpl implements bowwowService{

	@Autowired
	private bowwowDAO bowwowDAO;
		
	@Override
	@Transactional
	public List<user> getUser(String userEmail) {
		// TODO Auto-generated method stub
		return bowwowDAO.getUser(userEmail);
	}

	@Override
	@Transactional
	public List<product> getProducts() {
		// TODO Auto-generated method stub
		return bowwowDAO.getProducts();
	}

	@Override
	@Transactional
	public List<product> searchProducts(String theName, String search) {
		// TODO Auto-generated method stub
		return bowwowDAO.searchProducts(theName, search);
	}
	
	@Override
	@Transactional
	public List<product> detailProducts(int proNum) {
		// TODO Auto-generated method stub
		return bowwowDAO.detailProducts(proNum);
	}

	@Override
	@Transactional
	public List<review> getReviews(int proNum) {
		// TODO Auto-generated method stub
		return bowwowDAO.getReviews(proNum);
	}	
	
	@Override
	@Transactional
	public void saveOrder(order theOrder) {
		bowwowDAO.saveOrder(theOrder);
		}
	
	@Override
	@Transactional
	public int orderNum(order o) {
		return bowwowDAO.orderNum(o).getOrder_num();
	}
	
	@Override
	@Transactional
	public void savaOrderDetail(order_detail theOd) {
		bowwowDAO.savaOrderDetail(theOd);
	}

	@Override
	@Transactional
	public void saveUser(user theUser) {
		bowwowDAO.saveUser(theUser);
		
	}
}
