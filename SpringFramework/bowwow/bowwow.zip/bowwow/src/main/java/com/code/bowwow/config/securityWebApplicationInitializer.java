package com.code.bowwow.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class securityWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

}
