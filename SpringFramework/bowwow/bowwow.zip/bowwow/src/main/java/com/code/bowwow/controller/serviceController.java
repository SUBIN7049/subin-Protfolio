package com.code.bowwow.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.code.bowwow.entity.*;

import com.code.bowwow.service.bowwowService;

@Controller
public class serviceController {
	
	@Autowired
	private bowwowService bowwowService;
	
	@GetMapping("/")
	public String showHome(Model theModel) {
		List<product> theProducts = bowwowService.getProducts();
		theModel.addAttribute("products", theProducts);
	return "home";
	}
	
	@GetMapping("/search")
	public String SearchProduct(@RequestParam("searchName") String theName, String search, Model theModel) {
		List<product> theProducts = bowwowService.searchProducts(theName, search);
		theModel.addAttribute("products", theProducts);
	return "home";
	}
	
	@GetMapping("/detail")
	public String detailProduct(@RequestParam("productNum") int proNum, Model theModel,Principal p) {
		System.out.println(p.getName());
		List<product> theProducts = bowwowService.detailProducts(proNum);
		List<review> thereview = bowwowService.getReviews(proNum);
		theModel.addAttribute("products", theProducts);
		theModel.addAttribute("reviews", thereview);
		System.out.println(proNum);
		System.out.println(thereview);
	return "detail";
	}
	
	@GetMapping("/add")
	public String order(order_detail s, Principal p) {
		
		order o = new order(p.getName());
		bowwowService.saveOrder(o);
		s.setOrder_num(bowwowService.orderNum(o));
		
		order_detail od = new order_detail(s.getOrder_num(),s.getProduct_count(),s.getProduct_name(),s.getProduct_price());
		bowwowService.savaOrderDetail(od);
		
		return "history";
	}
	
	
}
