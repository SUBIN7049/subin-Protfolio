package com.code.bowwow.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.code.bowwow.entity.order;
import com.code.bowwow.entity.order_detail;
import com.code.bowwow.entity.product;
import com.code.bowwow.entity.review;
import com.code.bowwow.entity.user;

@Repository
public class bowwowDAOImpl implements bowwowDAO{
	
	
	
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	   public List<user> getUser(String userEmail) {
	      
	      Session curSession = sessionFactory.getCurrentSession();
	      Query<user> theQuery = curSession.createQuery("FROM user where email=:userEmail", user.class);
	      theQuery.setParameter("userEmail",userEmail);
	      List<user> theUser = theQuery.getResultList();
	      return theUser;
	   }
	
	
	@Override
	public List<product> getProducts() {
		
		Session curSession = sessionFactory.getCurrentSession();
		Query<product> theQuery = curSession.createQuery("FROM product", product.class);
		List<product> theProduct = theQuery.getResultList();
		return theProduct;
	}
	
	@Override
	public List<product> searchProducts(String theName, String search) {
		Session curSession = sessionFactory.getCurrentSession();
		StringBuilder sb = new StringBuilder("From product where ");
		sb.append(search);
		sb.append(" Like :searchName");
		
		theName = theName.replace(" ","");
		Query<product> theQuery = null;
		
		if(theName != null && theName.length() > 0) {
		theQuery = curSession.createQuery(sb.toString(), product.class);
		theQuery.setParameter("searchName", "%" + theName + "%");
		}else {
			theQuery = curSession.createQuery("FROM product", product.class);
		}
		List<product> theProduct = theQuery.getResultList();
		
		return theProduct;
	}
	
	@Override
	public List<product> detailProducts(int proNum) {
		
		Session curSession = sessionFactory.getCurrentSession();
		Query<product> theQuery = curSession.createQuery("FROM product where product_num = :productNum", product.class);
		theQuery.setParameter("productNum", proNum);
		List<product> theProduct = theQuery.getResultList();
		return theProduct;
	}
	
	@Override
	public List<review> getReviews(int proNum) {
		
		Session curSession = sessionFactory.getCurrentSession();
		//Query<review> theQuery = curSession.createQuery("select r.coment, r.username, r.coment_date, r.product_score from review r left join product p on r.product_num = p.product_num where p.product_num = :productNum", review.class);
		Query<review> theQuery = curSession.createQuery("FROM review where product_num = :productNum", review.class);
		theQuery.setParameter("productNum", proNum);
		List<review> thereview = theQuery.getResultList();
		return thereview;
	}
	
	@Override
	public void saveOrder(order theOrder){

		Session curSession = sessionFactory.getCurrentSession();
		
		curSession.saveOrUpdate(theOrder);
		System.out.println(11);
		
	}
	
	@Override
	public void saveUser(user theUser){

		Session curSession = sessionFactory.getCurrentSession();
		
		curSession.saveOrUpdate(theUser);
		System.out.println(11);
		
	}
	
	@Override
	public order orderNum(order o) {
		
		System.out.println(1);
		Session curSession = sessionFactory.getCurrentSession();
		Query<order> theQuery = curSession.createQuery("FROM order where email =:Order ORDER by day_time desc",order.class);
		theQuery.setMaxResults(1);
		theQuery.setParameter("Order", o.getEmail());
		
		return theQuery.getSingleResult();
	}
	
	@Override
	public void savaOrderDetail(order_detail theOd) {
		Session curSession = sessionFactory.getCurrentSession();
		System.out.println(2);
		curSession.saveOrUpdate(theOd);
		
	}
}
