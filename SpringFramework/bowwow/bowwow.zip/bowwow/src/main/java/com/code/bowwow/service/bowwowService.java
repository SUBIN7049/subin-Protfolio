package com.code.bowwow.service;

import java.util.List;

import com.code.bowwow.entity.order;
import com.code.bowwow.entity.order_detail;
import com.code.bowwow.entity.product;
import com.code.bowwow.entity.review;
import com.code.bowwow.entity.user;

public interface bowwowService {

	public List<user> getUser(String userEmail);
	
	public List<product> getProducts();

	public List<product> searchProducts(String theName, String search);
	
	public List<product> detailProducts(int proNum);

	public List<review> getReviews(int proNum);
	
	public void saveOrder(order theOrder);
	
	public int orderNum(order o);
	
	public void savaOrderDetail(order_detail theOd);
	
	public void saveUser(user theUser);
}
