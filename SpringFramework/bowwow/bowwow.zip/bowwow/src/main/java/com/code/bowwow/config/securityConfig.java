package com.code.bowwow.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;

import com.code.bowwow.service.bowwowService;

@Configuration
@EnableWebSecurity
public class securityConfig extends WebSecurityConfigurerAdapter {
	
	private bowwowService bowwowService;
	
	@Autowired
	private DataSource securityDataSource;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		/*
		 * UserBuilder users = User.withDefaultPasswordEncoder();
		 * auth.inMemoryAuthentication()
		 * .withUser(users.username("john@email.com").password("123").roles("EMPLOYEE"))
		 * .withUser(users.username("mary@email.com").password("123").roles("EMPLOYEE",
		 * "MANAGER"))
		 * .withUser(users.username("susan@email.com").password("123").roles("EMPLOYEE",
		 * "ADMIN"));
		 */
		
		
		auth.jdbcAuthentication()
		.dataSource(securityDataSource)
		.usersByUsernameQuery("SELECT email, password, 'true' AS enabled FROM user WHERE email=?")  //username:email , enabled:true
		.authoritiesByUsernameQuery("SELECT email, grade FROM user WHERE email=?")  // 권한부여
		;
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    http.authorizeRequests()
	    		.antMatchers("/css/**").permitAll()
	    		.antMatchers("/", "/home").permitAll()   // home페이지 로그인없이 접근 가능
//	    		.antMatchers("/").hasRole("EMPLOYEE")
//	    		.antMatchers("/leaders/**").hasAnyRole("MANAGER", "ADMIN")
//	    		.antMatchers("/systems/**").hasRole("ADMIN")
	        .and()
	        .formLogin()
	        	.loginPage("/login")
	            .loginProcessingUrl("/authenticateTheUser")
	            .permitAll()
	           .and() 
	           .logout().permitAll()
	           .and()
	           .exceptionHandling().accessDeniedPage("/access-denide")
	           ;
	           
	}
}
